<?php 
  if (isset($_GET['sentence'])){
    $sentence = $_GET['sentence'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "examen";

    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT sentence FROM refranero WHERE sentence LIKE ‘[info a buscar]%’";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo $row['iso'];
        }
    }
    $conn->close();
}

?>